interface StatusIndicatorProps {
  status: "online" | "offline" | "warning" | "processing";
  label?: string;
  showPulse?: boolean;
}

export function StatusIndicator({ status, label, showPulse = true }: StatusIndicatorProps) {
  const colors = {
    online: "bg-green-500",
    offline: "bg-red-500",
    warning: "bg-orange-500",
    processing: "bg-blue-500",
  };

  const textColors = {
    online: "text-green-700",
    offline: "text-red-700",
    warning: "text-orange-700",
    processing: "text-blue-700",
  };

  return (
    <div className="flex items-center gap-2">
      <div className="relative">
        <div className={`w-2 h-2 rounded-full ${colors[status]}`} />
        {showPulse && status !== "offline" && (
          <div className={`absolute inset-0 w-2 h-2 rounded-full ${colors[status]} animate-ping opacity-75`} />
        )}
      </div>
      {label && (
        <span className={`text-sm font-medium ${textColors[status]}`}>
          {label}
        </span>
      )}
    </div>
  );
}
