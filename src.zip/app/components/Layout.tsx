import { Outlet, Link, useLocation } from "react-router";
import { 
  Shield, 
  AlertTriangle, 
  Bug, 
  GitBranch, 
  FileText, 
  Archive,
  Activity 
} from "lucide-react";
import { cn } from "./ui/utils";
import { StatusIndicator } from "./StatusIndicator";

const navigation = [
  { name: "Dashboard", href: "/", icon: Activity },
  { name: "Alertas", href: "/alerts", icon: AlertTriangle },
  { name: "Vulnerabilidades", href: "/vulnerabilities", icon: Bug },
  { name: "Fluxo SOAR", href: "/soar-flow", icon: GitBranch },
  { name: "Logs de Auditoria", href: "/audit-logs", icon: FileText },
  { name: "Quarentena", href: "/quarantine", icon: Archive },
];

export function Layout() {
  const location = useLocation();

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-slate-900 text-white shadow-lg">
        <div className="mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield className="w-8 h-8 text-blue-400" />
              <div>
                <h1 className="text-xl font-bold">SOAR Platform - Wazuh Integration</h1>
                <p className="text-sm text-slate-300">Security Orchestration, Automation & Response</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="bg-slate-800 px-4 py-2 rounded-lg">
                <StatusIndicator status="online" label="Wazuh Connected" />
              </div>
              <div className="text-right">
                <p className="text-xs text-slate-400">Analista</p>
                <p className="text-sm font-medium">admin@security.local</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b border-slate-200 shadow-sm">
        <div className="mx-auto px-6">
          <div className="flex gap-1">
            {navigation.map((item) => {
              const isActive = location.pathname === item.href || 
                (item.href !== "/" && location.pathname.startsWith(item.href));
              const Icon = item.icon;
              
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  className={cn(
                    "flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors",
                    isActive
                      ? "border-blue-500 text-blue-600"
                      : "border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300"
                  )}
                >
                  <Icon className="w-4 h-4" />
                  {item.name}
                </Link>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="mx-auto px-6 py-8">
        <Outlet />
      </main>
    </div>
  );
}