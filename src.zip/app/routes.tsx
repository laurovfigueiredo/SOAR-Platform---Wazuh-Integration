import { createBrowserRouter } from "react-router";
import { Dashboard } from "./pages/Dashboard";
import { Alerts } from "./pages/Alerts";
import { Vulnerabilities } from "./pages/Vulnerabilities";
import { SOARFlow } from "./pages/SOARFlow";
import { AuditLogs } from "./pages/AuditLogs";
import { Quarantine } from "./pages/Quarantine";
import { AlertDetails } from "./pages/AlertDetails";
import { VulnerabilityDetails } from "./pages/VulnerabilityDetails";
import { Layout } from "./components/Layout";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Dashboard },
      { path: "alerts", Component: Alerts },
      { path: "alerts/:id", Component: AlertDetails },
      { path: "vulnerabilities", Component: Vulnerabilities },
      { path: "vulnerabilities/:id", Component: VulnerabilityDetails },
      { path: "soar-flow", Component: SOARFlow },
      { path: "audit-logs", Component: AuditLogs },
      { path: "quarantine", Component: Quarantine },
    ],
  },
]);
