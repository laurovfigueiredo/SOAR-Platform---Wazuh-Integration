import { useState } from "react";
import { Link } from "react-router";
import { AlertTriangle, Filter, Search } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Input } from "../components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { mockAlerts } from "../data/mockData";
import { Alert, AlertLevel } from "../types";

export function Alerts() {
  const [searchTerm, setSearchTerm] = useState("");
  const [levelFilter, setLevelFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const filteredAlerts = mockAlerts.filter((alert) => {
    const matchesSearch = 
      alert.rule.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      alert.agentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      alert.agentIp.includes(searchTerm);

    const matchesLevel = 
      levelFilter === "all" || 
      (levelFilter === "critical" && alert.level >= 12) ||
      (levelFilter === "high" && alert.level >= 8 && alert.level < 12) ||
      (levelFilter === "medium" && alert.level >= 5 && alert.level < 8);

    const matchesStatus = statusFilter === "all" || alert.status === statusFilter;

    return matchesSearch && matchesLevel && matchesStatus;
  });

  const getLevelBadgeVariant = (level: AlertLevel) => {
    if (level >= 12) return "destructive";
    if (level >= 8) return "default";
    return "secondary";
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      pending: { label: "Pendente", className: "bg-orange-100 text-orange-800" },
      analyzing: { label: "Analisando", className: "bg-blue-100 text-blue-800" },
      awaiting_decision: { label: "Aguardando Decisão", className: "bg-purple-100 text-purple-800" },
      resolved: { label: "Resolvido", className: "bg-green-100 text-green-800" },
      ignored: { label: "Ignorado", className: "bg-slate-100 text-slate-800" },
      quarantined: { label: "Quarentena", className: "bg-red-100 text-red-800" },
    };
    const variant = variants[status as keyof typeof variants] || variants.pending;
    return <Badge className={variant.className}>{variant.label}</Badge>;
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Alertas do Wazuh</h2>
        <p className="text-slate-600 mt-1">
          Monitoramento de alertas críticos (Níveis 5-12 e 15+)
        </p>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Buscar por descrição, agente ou IP..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={levelFilter} onValueChange={setLevelFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Nível" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os níveis</SelectItem>
                <SelectItem value="critical">Crítico (12-15)</SelectItem>
                <SelectItem value="high">Alto (8-11)</SelectItem>
                <SelectItem value="medium">Médio (5-7)</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os status</SelectItem>
                <SelectItem value="pending">Pendente</SelectItem>
                <SelectItem value="analyzing">Analisando</SelectItem>
                <SelectItem value="awaiting_decision">Aguardando Decisão</SelectItem>
                <SelectItem value="resolved">Resolvido</SelectItem>
                <SelectItem value="ignored">Ignorado</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <div className="text-sm text-slate-600 flex items-center gap-2">
        <Filter className="w-4 h-4" />
        Mostrando {filteredAlerts.length} de {mockAlerts.length} alertas
      </div>

      {/* Alerts List */}
      <div className="space-y-4">
        {filteredAlerts.map((alert) => (
          <Link key={alert.id} to={`/alerts/${alert.id}`}>
            <Card className="hover:shadow-lg transition-shadow cursor-pointer hover:border-blue-300">
              <CardContent className="p-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex gap-4 flex-1">
                    <div className="mt-1">
                      <AlertTriangle 
                        className={`w-6 h-6 ${
                          alert.level >= 12 ? 'text-red-600' : 
                          alert.level >= 8 ? 'text-orange-600' : 
                          'text-yellow-600'
                        }`} 
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant={getLevelBadgeVariant(alert.level)}>
                          Level {alert.level}
                        </Badge>
                        {getStatusBadge(alert.status)}
                        <span className="text-xs text-slate-500">
                          ID: {alert.rule.id}
                        </span>
                      </div>
                      <h3 className="font-semibold text-slate-900 mb-2">
                        {alert.rule.description}
                      </h3>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                        <div>
                          <span className="text-slate-600">Agente:</span>
                          <p className="font-medium text-slate-900">{alert.agentName}</p>
                        </div>
                        <div>
                          <span className="text-slate-600">IP Agente:</span>
                          <p className="font-medium text-slate-900">{alert.agentIp}</p>
                        </div>
                        {alert.sourceIp && (
                          <div>
                            <span className="text-slate-600">IP Origem:</span>
                            <p className="font-medium text-slate-900">{alert.sourceIp}</p>
                          </div>
                        )}
                        <div>
                          <span className="text-slate-600">Timestamp:</span>
                          <p className="font-medium text-slate-900">
                            {new Date(alert.timestamp).toLocaleString('pt-BR')}
                          </p>
                        </div>
                      </div>
                      {alert.rule.mitre.length > 0 && (
                        <div className="flex items-center gap-2 mt-3">
                          <span className="text-xs text-slate-600">MITRE ATT&CK:</span>
                          {alert.rule.mitre.map((technique) => (
                            <Badge key={technique} variant="outline" className="text-xs">
                              {technique}
                            </Badge>
                          ))}
                        </div>
                      )}
                      {alert.threatIntel && alert.threatIntel.length > 0 && (
                        <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                          <p className="text-sm font-medium text-red-900">
                            ⚠️ Threat Intelligence: {alert.threatIntel[0].details}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
