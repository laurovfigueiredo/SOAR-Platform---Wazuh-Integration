import { useState } from "react";
import { Link } from "react-router";
import { Bug, Filter, Search, AlertTriangle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Input } from "../components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { mockVulnerabilities } from "../data/mockData";

export function Vulnerabilities() {
  const [searchTerm, setSearchTerm] = useState("");
  const [severityFilter, setSeverityFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const filteredVulns = mockVulnerabilities.filter((vuln) => {
    const matchesSearch = 
      vuln.cve.toLowerCase().includes(searchTerm.toLowerCase()) ||
      vuln.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      vuln.agentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      vuln.package.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesSeverity = severityFilter === "all" || vuln.severity === severityFilter;
    const matchesStatus = statusFilter === "all" || vuln.status === statusFilter;

    return matchesSearch && matchesSeverity && matchesStatus;
  });

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-300';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-300';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'low': return 'bg-blue-100 text-blue-800 border-blue-300';
      default: return 'bg-slate-100 text-slate-800 border-slate-300';
    }
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      detected: { label: "Detectado", className: "bg-red-100 text-red-800" },
      analyzing: { label: "Analisando", className: "bg-blue-100 text-blue-800" },
      awaiting_patch: { label: "Aguardando Patch", className: "bg-purple-100 text-purple-800" },
      patching: { label: "Aplicando Patch", className: "bg-orange-100 text-orange-800" },
      resolved: { label: "Resolvido", className: "bg-green-100 text-green-800" },
      quarantined: { label: "Quarentena", className: "bg-slate-100 text-slate-800" },
    };
    const variant = variants[status as keyof typeof variants] || variants.detected;
    return <Badge className={variant.className}>{variant.label}</Badge>;
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Vulnerabilidades Detectadas</h2>
        <p className="text-slate-600 mt-1">
          Monitoramento de CVEs via Wazuh Vulnerability Detector
        </p>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Buscar por CVE, descrição, pacote ou agente..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={severityFilter} onValueChange={setSeverityFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Severidade" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas as severidades</SelectItem>
                <SelectItem value="critical">Crítica</SelectItem>
                <SelectItem value="high">Alta</SelectItem>
                <SelectItem value="medium">Média</SelectItem>
                <SelectItem value="low">Baixa</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os status</SelectItem>
                <SelectItem value="detected">Detectado</SelectItem>
                <SelectItem value="analyzing">Analisando</SelectItem>
                <SelectItem value="awaiting_patch">Aguardando Patch</SelectItem>
                <SelectItem value="patching">Aplicando Patch</SelectItem>
                <SelectItem value="resolved">Resolvido</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <div className="text-sm text-slate-600 flex items-center gap-2">
        <Filter className="w-4 h-4" />
        Mostrando {filteredVulns.length} de {mockVulnerabilities.length} vulnerabilidades
      </div>

      {/* Vulnerabilities List */}
      <div className="space-y-4">
        {filteredVulns.map((vuln) => (
          <Link key={vuln.id} to={`/vulnerabilities/${vuln.id}`}>
            <Card className="hover:shadow-lg transition-shadow cursor-pointer hover:border-purple-300">
              <CardContent className="p-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex gap-4 flex-1">
                    <div className="mt-1">
                      <Bug 
                        className={`w-6 h-6 ${
                          vuln.severity === 'critical' ? 'text-red-600' : 
                          vuln.severity === 'high' ? 'text-orange-600' : 
                          vuln.severity === 'medium' ? 'text-yellow-600' :
                          'text-blue-600'
                        }`} 
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2 flex-wrap">
                        <Badge className={getSeverityColor(vuln.severity) + " border"}>
                          {vuln.severity.toUpperCase()}
                        </Badge>
                        {getStatusBadge(vuln.status)}
                        <Badge variant="outline" className="font-mono">
                          {vuln.cve}
                        </Badge>
                        <span className="flex items-center gap-1 text-xs text-slate-600">
                          <span>CVSS:</span>
                          <span className={`font-bold ${
                            vuln.cvssScore >= 9 ? 'text-red-600' :
                            vuln.cvssScore >= 7 ? 'text-orange-600' :
                            vuln.cvssScore >= 4 ? 'text-yellow-600' :
                            'text-blue-600'
                          }`}>
                            {vuln.cvssScore}
                          </span>
                        </span>
                        {vuln.exploitable && (
                          <Badge variant="destructive" className="animate-pulse">
                            <AlertTriangle className="w-3 h-3 mr-1" />
                            Explorável
                          </Badge>
                        )}
                      </div>
                      <h3 className="font-semibold text-slate-900 mb-2">
                        {vuln.description}
                      </h3>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                        <div>
                          <span className="text-slate-600">Agente:</span>
                          <p className="font-medium text-slate-900">{vuln.agentName}</p>
                        </div>
                        <div>
                          <span className="text-slate-600">IP:</span>
                          <p className="font-medium text-slate-900">{vuln.agentIp}</p>
                        </div>
                        <div>
                          <span className="text-slate-600">Pacote:</span>
                          <p className="font-medium text-slate-900">{vuln.package}</p>
                        </div>
                        <div>
                          <span className="text-slate-600">Versão:</span>
                          <p className="font-medium text-slate-900">{vuln.version}</p>
                        </div>
                      </div>
                      {vuln.patchAvailable && (
                        <div className="mt-3 p-2 bg-green-50 border border-green-200 rounded flex items-center gap-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full" />
                          <span className="text-sm text-green-800">
                            Patch disponível: {vuln.patchVersion}
                          </span>
                        </div>
                      )}
                      {vuln.threatIntel && vuln.threatIntel.length > 0 && (
                        <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                          <p className="text-sm font-medium text-red-900">
                            ⚠️ {vuln.threatIntel[0].details}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
