import { useState } from "react";
import { Archive, Trash2, RotateCcw, AlertTriangle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import { mockQuarantineItems } from "../data/mockData";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "../components/ui/alert-dialog";

export function Quarantine() {
  const [items, setItems] = useState(mockQuarantineItems);

  const handleRestore = (id: string) => {
    toast.success("Item restaurado!", {
      description: "O item foi removido da quarentena e restaurado ao sistema"
    });
    setItems(items.filter(item => item.id !== id));
  };

  const handleDelete = (id: string) => {
    toast.success("Item excluído permanentemente!", {
      description: "O item foi removido da quarentena de forma permanente"
    });
    setItems(items.filter(item => item.id !== id));
  };

  const getTypeBadge = (type: string) => {
    return type === "alert" ? (
      <Badge variant="destructive">Alerta</Badge>
    ) : (
      <Badge className="bg-purple-600 text-white">Vulnerabilidade</Badge>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Quarentena</h2>
          <p className="text-slate-600 mt-1">
            Itens isolados do sistema por motivos de segurança
          </p>
        </div>
        <Badge variant="outline" className="text-base px-4 py-2">
          {items.length} {items.length === 1 ? 'item' : 'itens'}
        </Badge>
      </div>

      {/* Info Banner */}
      <Card className="bg-orange-50 border-2 border-orange-300">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-semibold text-orange-900">Sobre a Quarentena</h4>
              <p className="text-sm text-orange-800 mt-1">
                Itens em quarentena foram isolados do sistema devido a ameaças confirmadas ou alto risco. 
                Você pode restaurá-los caso tenha certeza de que não representam perigo, ou excluí-los permanentemente.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Total em Quarentena</p>
                <p className="text-2xl font-bold text-slate-900 mt-1">{items.length}</p>
              </div>
              <Archive className="w-8 h-8 text-slate-600 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Alertas</p>
                <p className="text-2xl font-bold text-red-600 mt-1">
                  {items.filter(i => i.type === 'alert').length}
                </p>
              </div>
              <AlertTriangle className="w-8 h-8 text-red-600 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Vulnerabilidades</p>
                <p className="text-2xl font-bold text-purple-600 mt-1">
                  {items.filter(i => i.type === 'vulnerability').length}
                </p>
              </div>
              <Archive className="w-8 h-8 text-purple-600 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quarantine Items */}
      {items.length > 0 ? (
        <div className="space-y-4">
          {items.map((item) => (
            <Card key={item.id} className="border-2 border-orange-300 bg-orange-50/30">
              <CardContent className="p-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex gap-4 flex-1">
                    <div className="mt-1">
                      <Archive className="w-6 h-6 text-orange-600" />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        {getTypeBadge(item.type)}
                        <span className="text-xs text-slate-500 font-mono">
                          ID Original: {item.originalId}
                        </span>
                      </div>
                      
                      <h3 className="font-semibold text-slate-900 mb-2">{item.description}</h3>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm mb-3">
                        <div>
                          <span className="text-slate-600">Agente:</span>
                          <p className="font-medium text-slate-900">{item.agentName}</p>
                        </div>
                        <div>
                          <span className="text-slate-600">IP:</span>
                          <p className="font-medium text-slate-900">{item.agentIp}</p>
                        </div>
                      </div>

                      <div className="p-3 bg-red-50 border border-red-200 rounded-lg mb-3">
                        <p className="text-sm text-red-900">
                          <strong>Motivo da quarentena:</strong> {item.reason}
                        </p>
                      </div>

                      <div className="flex items-center gap-4 text-sm text-slate-600">
                        <div>
                          <span className="text-slate-500">Isolado por:</span>{" "}
                          <span className="font-medium">{item.analyst}</span>
                        </div>
                        <div>
                          <span className="text-slate-500">Data:</span>{" "}
                          <span className="font-medium">
                            {new Date(item.timestamp).toLocaleString('pt-BR')}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-col gap-2">
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="outline" size="sm" className="whitespace-nowrap">
                          <RotateCcw className="w-4 h-4 mr-2" />
                          Restaurar
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Restaurar item da quarentena?</AlertDialogTitle>
                          <AlertDialogDescription>
                            Tem certeza que deseja restaurar este item? Ele será removido da quarentena 
                            e voltará ao estado ativo no sistema.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancelar</AlertDialogCancel>
                          <AlertDialogAction onClick={() => handleRestore(item.id)}>
                            Restaurar
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>

                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="destructive" size="sm" className="whitespace-nowrap">
                          <Trash2 className="w-4 h-4 mr-2" />
                          Excluir
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Excluir permanentemente?</AlertDialogTitle>
                          <AlertDialogDescription>
                            Esta ação não pode ser desfeita. O item será removido permanentemente 
                            do sistema e não poderá ser recuperado.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancelar</AlertDialogCancel>
                          <AlertDialogAction 
                            onClick={() => handleDelete(item.id)}
                            className="bg-red-600 hover:bg-red-700"
                          >
                            Excluir
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="py-12">
            <div className="text-center text-slate-500">
              <Archive className="w-16 h-16 mx-auto mb-4 opacity-30" />
              <h3 className="text-lg font-semibold text-slate-900 mb-2">
                Nenhum item em quarentena
              </h3>
              <p className="text-sm">
                Quando você isolar alertas ou vulnerabilidades, eles aparecerão aqui.
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Help Card */}
      <Card className="bg-blue-50 border-2 border-blue-300">
        <CardHeader>
          <CardTitle className="text-sm">Como funciona a Quarentena?</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 text-sm text-slate-700">
            <div className="flex items-start gap-2">
              <div className="w-2 h-2 bg-blue-600 rounded-full mt-1.5 flex-shrink-0" />
              <p>
                <strong>Isolamento:</strong> Itens em quarentena estão isolados do sistema e não podem 
                causar danos adicionais.
              </p>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-2 h-2 bg-blue-600 rounded-full mt-1.5 flex-shrink-0" />
              <p>
                <strong>Restauração:</strong> Se você confirmar que um item não representa ameaça, 
                pode restaurá-lo ao sistema.
              </p>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-2 h-2 bg-blue-600 rounded-full mt-1.5 flex-shrink-0" />
              <p>
                <strong>Exclusão:</strong> Itens confirmados como maliciosos devem ser excluídos 
                permanentemente para garantir a segurança.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
