import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { 
  Radio, 
  Filter, 
  Activity, 
  Search, 
  Shield, 
  Hammer, 
  CheckCircle, 
  Archive,
  ArrowRight,
  Database,
  AlertTriangle
} from "lucide-react";
import { Badge } from "../components/ui/badge";

const flowSteps = [
  {
    number: 1,
    title: "Ingestão e Escuta",
    subtitle: "Event Listener",
    icon: Radio,
    color: "bg-blue-500",
    description: "Conexão com Wazuh via API ou monitoramento de alerts.json",
    details: [
      "Filtragem de alertas críticos (Level 5-12, 15+)",
      "Monitoramento do Vulnerability Detector",
      "Detecção via Threat Hunter",
    ],
    techStack: "Python + Wazuh API / alerts.json"
  },
  {
    number: 2,
    title: "Enriquecimento de Contexto",
    subtitle: "Auto-Threat Intel",
    icon: Search,
    color: "bg-purple-500",
    description: "Validação automática de gravidade via fontes externas",
    details: [
      "Integração com VirusTotal API",
      "Consulta ao AbuseIPDB",
      "Verificação em URLVoid",
      "Análise de reputação de IPs/arquivos",
    ],
    techStack: "requests + APIs de Threat Intel"
  },
  {
    number: 3,
    title: "Validação Controlada",
    subtitle: "Validation Step",
    icon: Activity,
    color: "bg-orange-500",
    description: "Exploração inócua para confirmar explorabilidade",
    details: [
      "Scripts Nmap NSE para validação",
      "Integração com Metasploit (msfconsole)",
      "Verificação de portas e serviços",
      "Confirmação de vulnerabilidade real",
    ],
    techStack: "Nmap + python-nmap / Metasploit"
  },
  {
    number: 4,
    title: "Painel de Decisão",
    subtitle: "The Gatekeeper",
    icon: Shield,
    color: "bg-red-500",
    description: "Interface para o analista tomar decisão imediata",
    details: [
      "Opção A: Contenção (Isolar host)",
      "Opção B: Remediação (Patch/Update)",
      "Opção C: Falso Positivo (Ignorar)",
    ],
    techStack: "Flask/FastAPI + React UI"
  },
  {
    number: 5,
    title: "Execução de Playbooks",
    subtitle: "Action",
    icon: Hammer,
    color: "bg-green-500",
    description: "Execução automatizada da ação escolhida",
    details: [
      "Bloqueio via iptables/nftables",
      "Atualização via yum/apt (SSH)",
      "Active Response do Wazuh",
      "Comandos via Ansible/Paramiko",
    ],
    techStack: "paramiko (SSH) + Ansible + Wazuh AR"
  },
  {
    number: 6,
    title: "Verificação e Fechamento",
    subtitle: "Double Check",
    icon: CheckCircle,
    color: "bg-teal-500",
    description: "Validação pós-ação e auditoria completa",
    details: [
      "Re-scan via Wazuh syscheck",
      "Verificação de status da vulnerabilidade",
      "Registro em banco de dados (SQLite/PostgreSQL)",
      "Log de quem autorizou e o que foi feito",
    ],
    techStack: "SQLite/PostgreSQL + Wazuh API"
  },
];

export function SOARFlow() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Fluxo SOAR - Arquitetura</h2>
        <p className="text-slate-600 mt-1">
          Fluxo completo de automação de detecção, tratamento e resposta a incidentes
        </p>
      </div>

      {/* Architecture Overview */}
      <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="w-5 h-5 text-blue-600" />
            Stack Tecnológica
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-white rounded-lg border border-blue-200">
              <h4 className="font-semibold text-slate-900 mb-2">Backend</h4>
              <div className="flex flex-wrap gap-2">
                <Badge>Python</Badge>
                <Badge>Go</Badge>
                <Badge>Flask</Badge>
                <Badge>FastAPI</Badge>
              </div>
            </div>
            <div className="p-4 bg-white rounded-lg border border-purple-200">
              <h4 className="font-semibold text-slate-900 mb-2">Integrações</h4>
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary">Wazuh API</Badge>
                <Badge variant="secondary">VirusTotal</Badge>
                <Badge variant="secondary">AbuseIPDB</Badge>
                <Badge variant="secondary">Nmap</Badge>
              </div>
            </div>
            <div className="p-4 bg-white rounded-lg border border-green-200">
              <h4 className="font-semibold text-slate-900 mb-2">Automação</h4>
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline">SSH/Paramiko</Badge>
                <Badge variant="outline">Ansible</Badge>
                <Badge variant="outline">Active Response</Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Flow Diagram */}
      <div className="relative">
        {/* Connection Lines */}
        <div className="absolute inset-0 flex flex-col items-center justify-between pointer-events-none z-0">
          {flowSteps.slice(0, -1).map((_, idx) => (
            <div 
              key={idx}
              className="w-1 bg-gradient-to-b from-blue-300 to-purple-300 flex-1 mx-auto"
              style={{ 
                marginTop: idx === 0 ? '120px' : '40px',
                marginBottom: '40px',
              }}
            />
          ))}
        </div>

        {/* Steps */}
        <div className="space-y-8 relative z-10">
          {flowSteps.map((step, idx) => {
            const Icon = step.icon;
            const isEven = idx % 2 === 0;
            
            return (
              <div key={step.number} className={`flex items-center gap-8 ${isEven ? '' : 'flex-row-reverse'}`}>
                {/* Step Number Circle */}
                <div className="flex-shrink-0 w-24 flex justify-center">
                  <div className={`${step.color} text-white w-16 h-16 rounded-full flex items-center justify-center shadow-lg`}>
                    <span className="text-2xl font-bold">{step.number}</span>
                  </div>
                </div>

                {/* Step Card */}
                <Card className="flex-1 hover:shadow-xl transition-shadow border-2">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`${step.color} text-white p-2 rounded-lg`}>
                          <Icon className="w-5 h-5" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{step.title}</CardTitle>
                          <p className="text-sm text-slate-600 mt-0.5">{step.subtitle}</p>
                        </div>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        Etapa {step.number}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-slate-700">{step.description}</p>
                    
                    <div className="space-y-2">
                      {step.details.map((detail, detailIdx) => (
                        <div key={detailIdx} className="flex items-start gap-2 text-sm">
                          <ArrowRight className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                          <span className="text-slate-600">{detail}</span>
                        </div>
                      ))}
                    </div>

                    <div className="pt-2 border-t border-slate-200">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-medium text-slate-600">Stack:</span>
                        <code className="text-xs bg-slate-100 px-2 py-1 rounded">
                          {step.techStack}
                        </code>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Spacer for alignment */}
                <div className="flex-shrink-0 w-24" />
              </div>
            );
          })}
        </div>
      </div>

      {/* Key Features */}
      <Card className="border-2 border-green-300 bg-gradient-to-br from-green-50 to-teal-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-green-600" />
            Diferenciais da Ferramenta
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-white rounded-lg border border-green-200">
              <h4 className="font-semibold text-slate-900 mb-2 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                Solução Pronta
              </h4>
              <p className="text-sm text-slate-600">
                Diferente de um SIEM comum que apenas avisa, esta ferramenta propõe a solução pronta. 
                O analista não precisa abrir o terminal do servidor afetado.
              </p>
            </div>

            <div className="p-4 bg-white rounded-lg border border-blue-200">
              <h4 className="font-semibold text-slate-900 mb-2 flex items-center gap-2">
                <Activity className="w-4 h-4 text-blue-600" />
                MTTR Reduzido
              </h4>
              <p className="text-sm text-slate-600">
                Redução do MTTR (Tempo Médio de Resposta) de <strong>horas para segundos</strong> através 
                da automação completa do fluxo de resposta.
              </p>
            </div>

            <div className="p-4 bg-white rounded-lg border border-purple-200">
              <h4 className="font-semibold text-slate-900 mb-2 flex items-center gap-2">
                <Filter className="w-4 h-4 text-purple-600" />
                Inteligência Automatizada
              </h4>
              <p className="text-sm text-slate-600">
                Enriquecimento automático com threat intelligence antes de alertar o analista, 
                eliminando ruídos e falsos positivos.
              </p>
            </div>

            <div className="p-4 bg-white rounded-lg border border-orange-200">
              <h4 className="font-semibold text-slate-900 mb-2 flex items-center gap-2">
                <Archive className="w-4 h-4 text-orange-600" />
                Auditoria Completa
              </h4>
              <p className="text-sm text-slate-600">
                Registro completo de todas as ações: quem autorizou, o que foi executado, 
                e se o status da vulnerabilidade mudou para "Resolved".
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Integration Points */}
      <Card>
        <CardHeader>
          <CardTitle>Pontos de Integração com Wazuh</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
              <div className="bg-blue-500 text-white p-2 rounded">
                <Database className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <h4 className="font-semibold text-slate-900">Wazuh API</h4>
                <p className="text-sm text-slate-600 mt-1">
                  Conexão via RESTful API para obter alertas, gerenciar agentes e executar scans
                </p>
                <code className="text-xs bg-white px-2 py-1 rounded mt-2 inline-block">
                  GET https://wazuh-manager:55000/security/events
                </code>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg border border-green-200">
              <div className="bg-green-500 text-white p-2 rounded">
                <Archive className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <h4 className="font-semibold text-slate-900">alerts.json</h4>
                <p className="text-sm text-slate-600 mt-1">
                  Monitoramento em tempo real do arquivo de alertas do Wazuh
                </p>
                <code className="text-xs bg-white px-2 py-1 rounded mt-2 inline-block">
                  /var/ossec/logs/alerts/alerts.json
                </code>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 bg-purple-50 rounded-lg border border-purple-200">
              <div className="bg-purple-500 text-white p-2 rounded">
                <Shield className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <h4 className="font-semibold text-slate-900">Active Response</h4>
                <p className="text-sm text-slate-600 mt-1">
                  Execução de scripts de resposta automática diretamente nos agentes Linux
                </p>
                <code className="text-xs bg-white px-2 py-1 rounded mt-2 inline-block">
                  /var/ossec/active-response/bin/
                </code>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
