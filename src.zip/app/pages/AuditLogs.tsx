import { useState } from "react";
import { FileText, CheckCircle, XCircle, Filter, Download, Calendar } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { mockAuditLogs } from "../data/mockData";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Button } from "../components/ui/button";
import { toast } from "sonner";

export function AuditLogs() {
  const [actionFilter, setActionFilter] = useState<string>("all");
  const [targetTypeFilter, setTargetTypeFilter] = useState<string>("all");

  const filteredLogs = mockAuditLogs.filter((log) => {
    const matchesAction = actionFilter === "all" || log.action === actionFilter;
    const matchesTargetType = targetTypeFilter === "all" || log.targetType === targetTypeFilter;
    return matchesAction && matchesTargetType;
  });

  const handleExport = () => {
    toast.success("Logs exportados!", {
      description: "Arquivo CSV baixado com sucesso"
    });
  };

  const getActionBadge = (action: string) => {
    const variants = {
      containment: { label: "Contenção", className: "bg-red-100 text-red-800" },
      remediation: { label: "Remediação", className: "bg-green-100 text-green-800" },
      ignore: { label: "Ignorar", className: "bg-slate-100 text-slate-800" },
      scan: { label: "Scan", className: "bg-blue-100 text-blue-800" },
      enrich: { label: "Enriquecimento", className: "bg-purple-100 text-purple-800" },
    };
    const variant = variants[action as keyof typeof variants] || { 
      label: action, 
      className: "bg-slate-100 text-slate-800" 
    };
    return <Badge className={variant.className}>{variant.label}</Badge>;
  };

  const getTargetTypeBadge = (targetType: string) => {
    return targetType === "alert" ? (
      <Badge variant="outline" className="border-red-300 text-red-700">Alerta</Badge>
    ) : (
      <Badge variant="outline" className="border-purple-300 text-purple-700">Vulnerabilidade</Badge>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Logs de Auditoria</h2>
          <p className="text-slate-600 mt-1">
            Registro completo de todas as ações executadas no sistema
          </p>
        </div>
        <Button onClick={handleExport} variant="outline">
          <Download className="w-4 h-4 mr-2" />
          Exportar CSV
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Total de Ações</p>
                <p className="text-2xl font-bold text-slate-900 mt-1">{mockAuditLogs.length}</p>
              </div>
              <FileText className="w-8 h-8 text-blue-600 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Sucessos</p>
                <p className="text-2xl font-bold text-green-600 mt-1">
                  {mockAuditLogs.filter(l => l.success).length}
                </p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Falhas</p>
                <p className="text-2xl font-bold text-red-600 mt-1">
                  {mockAuditLogs.filter(l => !l.success).length}
                </p>
              </div>
              <XCircle className="w-8 h-8 text-red-600 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">Hoje</p>
                <p className="text-2xl font-bold text-slate-900 mt-1">
                  {mockAuditLogs.filter(l => 
                    new Date(l.timestamp).toDateString() === new Date().toDateString()
                  ).length}
                </p>
              </div>
              <Calendar className="w-8 h-8 text-purple-600 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Select value={actionFilter} onValueChange={setActionFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Tipo de Ação" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas as ações</SelectItem>
                <SelectItem value="containment">Contenção</SelectItem>
                <SelectItem value="remediation">Remediação</SelectItem>
                <SelectItem value="ignore">Ignorar</SelectItem>
                <SelectItem value="scan">Scan</SelectItem>
                <SelectItem value="enrich">Enriquecimento</SelectItem>
              </SelectContent>
            </Select>

            <Select value={targetTypeFilter} onValueChange={setTargetTypeFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Tipo de Alvo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os tipos</SelectItem>
                <SelectItem value="alert">Alertas</SelectItem>
                <SelectItem value="vulnerability">Vulnerabilidades</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Filter className="w-4 h-4" />
              Mostrando {filteredLogs.length} de {mockAuditLogs.length} logs
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Logs List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            Histórico de Ações
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {filteredLogs.map((log) => (
              <div 
                key={log.id}
                className={`p-4 rounded-lg border-2 transition-all ${
                  log.success 
                    ? 'bg-white border-slate-200 hover:border-blue-300' 
                    : 'bg-red-50 border-red-200'
                }`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3 flex-1">
                    {log.success ? (
                      <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                    )}
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2 flex-wrap">
                        {getActionBadge(log.action)}
                        {getTargetTypeBadge(log.targetType)}
                        <span className="text-xs text-slate-500 font-mono">ID: {log.target}</span>
                      </div>
                      
                      <p className="text-slate-900 font-medium mb-1">{log.details}</p>
                      
                      <div className="flex items-center gap-4 text-sm text-slate-600 mt-2">
                        <div className="flex items-center gap-1">
                          <span className="text-slate-500">Analista:</span>
                          <span className="font-medium">{log.analyst}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="text-slate-500">Data:</span>
                          <span className="font-medium">
                            {new Date(log.timestamp).toLocaleString('pt-BR')}
                          </span>
                        </div>
                      </div>

                      {log.oldStatus && log.newStatus && (
                        <div className="mt-3 pt-3 border-t border-slate-200">
                          <div className="flex items-center gap-3 text-sm">
                            <span className="text-slate-600">Mudança de status:</span>
                            <Badge variant="outline">{log.oldStatus}</Badge>
                            <span className="text-slate-400">→</span>
                            <Badge variant="outline" className="border-green-300 text-green-700">
                              {log.newStatus}
                            </Badge>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}

            {filteredLogs.length === 0 && (
              <div className="text-center py-12 text-slate-500">
                <FileText className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p>Nenhum log encontrado com os filtros selecionados</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Legend */}
      <Card className="bg-slate-50 border-slate-300">
        <CardHeader>
          <CardTitle className="text-sm">Legenda</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <span className="text-slate-700">Ação executada com sucesso</span>
            </div>
            <div className="flex items-center gap-2">
              <XCircle className="w-4 h-4 text-red-600" />
              <span className="text-slate-700">Ação falhou durante execução</span>
            </div>
            <div className="flex items-center gap-2">
              {getActionBadge("containment")}
              <span className="text-slate-700">Host isolado da rede</span>
            </div>
            <div className="flex items-center gap-2">
              {getActionBadge("remediation")}
              <span className="text-slate-700">Patch aplicado ou processo terminado</span>
            </div>
            <div className="flex items-center gap-2">
              {getActionBadge("scan")}
              <span className="text-slate-700">Re-scan executado via Wazuh</span>
            </div>
            <div className="flex items-center gap-2">
              {getActionBadge("enrich")}
              <span className="text-slate-700">Dados de threat intelligence obtidos</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
