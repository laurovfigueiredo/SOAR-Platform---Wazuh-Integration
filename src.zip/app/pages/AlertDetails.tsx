import { useState } from "react";
import { useParams, useNavigate, Link } from "react-router";
import { 
  AlertTriangle, 
  ArrowLeft, 
  Shield, 
  Wrench, 
  X, 
  RefreshCw,
  CheckCircle,
  ExternalLink,
  Terminal,
  Activity
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import { mockAlerts } from "../data/mockData";
import { toast } from "sonner";
import { Separator } from "../components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";

export function AlertDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const alert = mockAlerts.find(a => a.id === id);
  const [isProcessing, setIsProcessing] = useState(false);
  const [enriching, setEnriching] = useState(false);

  if (!alert) {
    return (
      <div className="text-center py-12">
        <AlertTriangle className="w-12 h-12 text-slate-400 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-slate-900">Alerta não encontrado</h3>
        <p className="text-slate-600 mt-2">O alerta solicitado não existe no sistema.</p>
        <Button onClick={() => navigate("/alerts")} className="mt-4">
          Voltar aos alertas
        </Button>
      </div>
    );
  }

  const handleEnrich = async () => {
    setEnriching(true);
    toast.loading("Enriquecendo contexto...");
    
    // Simular chamada às APIs de Threat Intel
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    toast.dismiss();
    toast.success("Enriquecimento concluído!", {
      description: "Dados obtidos de VirusTotal e AbuseIPDB"
    });
    setEnriching(false);
  };

  const handleContainment = async () => {
    setIsProcessing(true);
    toast.loading("Executando contenção...");
    
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    toast.dismiss();
    toast.success("Host isolado com sucesso!", {
      description: `IP ${alert.sourceIp} bloqueado via iptables em ${alert.agentName}`
    });
    
    setTimeout(() => {
      navigate("/alerts");
    }, 1500);
  };

  const handleRemediation = async () => {
    setIsProcessing(true);
    toast.loading("Executando remediação...");
    
    await new Promise(resolve => setTimeout(resolve, 2500));
    
    toast.dismiss();
    toast.success("Remediação aplicada!", {
      description: "Active Response executado com sucesso via Wazuh"
    });
    
    setTimeout(() => {
      navigate("/alerts");
    }, 1500);
  };

  const handleIgnore = async () => {
    setIsProcessing(true);
    toast.loading("Processando...");
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    toast.dismiss();
    toast.info("Alerta marcado como falso positivo", {
      description: "Adicionado às exceções"
    });
    
    setTimeout(() => {
      navigate("/alerts");
    }, 1500);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to="/alerts">
            <Button variant="outline" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
          </Link>
          <div>
            <h2 className="text-2xl font-bold text-slate-900">Detalhes do Alerta</h2>
            <p className="text-slate-600 mt-1">ID: {alert.id}</p>
          </div>
        </div>
        <Badge 
          variant={alert.level >= 12 ? "destructive" : alert.level >= 8 ? "default" : "secondary"}
          className="text-base px-4 py-2"
        >
          Level {alert.level}
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Info */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-600" />
                Informações do Alerta
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium text-slate-600">Descrição</label>
                <p className="text-lg font-semibold text-slate-900 mt-1">{alert.rule.description}</p>
              </div>

              <Separator />

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-slate-600">Regra Wazuh</label>
                  <p className="text-slate-900 mt-1">ID: {alert.rule.id}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-slate-600">Timestamp</label>
                  <p className="text-slate-900 mt-1">{new Date(alert.timestamp).toLocaleString('pt-BR')}</p>
                </div>
              </div>

              <Separator />

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-slate-600">Agente</label>
                  <p className="text-slate-900 mt-1">{alert.agentName}</p>
                  <p className="text-sm text-slate-600">ID: {alert.agentId}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-slate-600">IP do Agente</label>
                  <p className="text-slate-900 mt-1">{alert.agentIp}</p>
                </div>
              </div>

              {alert.sourceIp && (
                <>
                  <Separator />
                  <div>
                    <label className="text-sm font-medium text-slate-600">IP de Origem (Atacante)</label>
                    <p className="text-lg font-mono font-bold text-red-600 mt-1">{alert.sourceIp}</p>
                  </div>
                </>
              )}

              {(alert.filePath || alert.processName) && (
                <>
                  <Separator />
                  <div className="grid grid-cols-1 gap-4">
                    {alert.filePath && (
                      <div>
                        <label className="text-sm font-medium text-slate-600">Caminho do Arquivo</label>
                        <p className="text-slate-900 font-mono text-sm mt-1">{alert.filePath}</p>
                      </div>
                    )}
                    {alert.processName && (
                      <div>
                        <label className="text-sm font-medium text-slate-600">Processo</label>
                        <p className="text-slate-900 font-mono text-sm mt-1">{alert.processName}</p>
                      </div>
                    )}
                  </div>
                </>
              )}

              {alert.rule.mitre.length > 0 && (
                <>
                  <Separator />
                  <div>
                    <label className="text-sm font-medium text-slate-600">MITRE ATT&CK Techniques</label>
                    <div className="flex gap-2 mt-2">
                      {alert.rule.mitre.map((technique) => (
                        <a
                          key={technique}
                          href={`https://attack.mitre.org/techniques/${technique.replace('.', '/')}/`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1"
                        >
                          <Badge variant="outline" className="hover:bg-slate-100 cursor-pointer">
                            {technique}
                            <ExternalLink className="w-3 h-3 ml-1" />
                          </Badge>
                        </a>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {/* Threat Intelligence */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-blue-600" />
                  Enriquecimento de Contexto (Threat Intel)
                </CardTitle>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={handleEnrich}
                  disabled={enriching || alert.enrichmentComplete}
                >
                  <RefreshCw className={`w-4 h-4 mr-2 ${enriching ? 'animate-spin' : ''}`} />
                  {alert.enrichmentComplete ? 'Atualizado' : 'Enriquecer'}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {alert.threatIntel && alert.threatIntel.length > 0 ? (
                <div className="space-y-4">
                  {alert.threatIntel.map((intel, idx) => (
                    <div 
                      key={idx}
                      className={`p-4 rounded-lg border-2 ${
                        intel.reputation === 'malicious' ? 'bg-red-50 border-red-300' :
                        intel.reputation === 'suspicious' ? 'bg-orange-50 border-orange-300' :
                        intel.reputation === 'clean' ? 'bg-green-50 border-green-300' :
                        'bg-slate-50 border-slate-300'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-slate-900">{intel.source}</span>
                          <Badge 
                            variant={intel.reputation === 'malicious' ? 'destructive' : 'default'}
                          >
                            {intel.reputation.toUpperCase()}
                          </Badge>
                        </div>
                        <div className="text-right">
                          <span className="text-2xl font-bold text-slate-900">{intel.score}</span>
                          <span className="text-sm text-slate-600">/100</span>
                        </div>
                      </div>
                      <p className="text-sm text-slate-700">{intel.details}</p>
                      {intel.lastAnalysis && (
                        <p className="text-xs text-slate-500 mt-2">
                          Última análise: {new Date(intel.lastAnalysis).toLocaleString('pt-BR')}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-slate-500">
                  <Activity className="w-12 h-12 mx-auto mb-3 opacity-30" />
                  <p>Nenhum dado de threat intelligence disponível</p>
                  <p className="text-sm mt-1">Clique em "Enriquecer" para obter informações</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Decision Panel - GATEKEEPER */}
        <div className="space-y-6">
          <Card className="border-2 border-blue-500 shadow-lg">
            <CardHeader className="bg-blue-50">
              <CardTitle className="flex items-center gap-2 text-blue-900">
                <Shield className="w-5 h-5" />
                Painel de Decisão
              </CardTitle>
              <p className="text-sm text-blue-700 mt-1">
                Escolha uma ação de resposta ao incidente
              </p>
            </CardHeader>
            <CardContent className="pt-6 space-y-3">
              {/* Opção A: Contenção */}
              <Button
                onClick={handleContainment}
                disabled={isProcessing}
                className="w-full h-auto py-4 bg-red-600 hover:bg-red-700"
                size="lg"
              >
                <div className="flex items-center gap-3 w-full">
                  <div className="bg-white/20 p-2 rounded">
                    <Shield className="w-5 h-5" />
                  </div>
                  <div className="text-left flex-1">
                    <div className="font-bold">Opção A: Contenção</div>
                    <div className="text-xs font-normal opacity-90">
                      Isolar host da rede via Active Response
                    </div>
                  </div>
                </div>
              </Button>

              {/* Opção B: Remediação */}
              <Button
                onClick={handleRemediation}
                disabled={isProcessing}
                className="w-full h-auto py-4 bg-orange-600 hover:bg-orange-700"
                size="lg"
              >
                <div className="flex items-center gap-3 w-full">
                  <div className="bg-white/20 p-2 rounded">
                    <Wrench className="w-5 h-5" />
                  </div>
                  <div className="text-left flex-1">
                    <div className="font-bold">Opção B: Remediação</div>
                    <div className="text-xs font-normal opacity-90">
                      Executar playbook de resposta
                    </div>
                  </div>
                </div>
              </Button>

              {/* Opção C: Falso Positivo */}
              <Button
                onClick={handleIgnore}
                disabled={isProcessing}
                variant="outline"
                className="w-full h-auto py-4 border-2"
                size="lg"
              >
                <div className="flex items-center gap-3 w-full">
                  <div className="bg-slate-100 p-2 rounded">
                    <X className="w-5 h-5 text-slate-700" />
                  </div>
                  <div className="text-left flex-1">
                    <div className="font-bold text-slate-900">Opção C: Ignorar</div>
                    <div className="text-xs font-normal text-slate-600">
                      Marcar como falso positivo
                    </div>
                  </div>
                </div>
              </Button>
            </CardContent>
          </Card>

          {/* Playbook Preview */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-sm">
                <Terminal className="w-4 h-4" />
                Preview do Playbook
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="containment" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="containment">Contenção</TabsTrigger>
                  <TabsTrigger value="remediation">Remediação</TabsTrigger>
                </TabsList>
                <TabsContent value="containment" className="space-y-2">
                  <div className="bg-slate-900 text-green-400 p-3 rounded font-mono text-xs space-y-1">
                    <div># Bloqueio via iptables</div>
                    <div>$ iptables -A INPUT -s {alert.sourceIp} -j DROP</div>
                    <div>$ iptables -A OUTPUT -d {alert.sourceIp} -j DROP</div>
                    <div className="text-slate-500"># Host isolado</div>
                  </div>
                </TabsContent>
                <TabsContent value="remediation" className="space-y-2">
                  <div className="bg-slate-900 text-green-400 p-3 rounded font-mono text-xs space-y-1">
                    <div># Active Response Wazuh</div>
                    <div>$ /var/ossec/active-response/bin/firewall-drop.sh</div>
                    <div>$ kill -9 {alert.processName || 'PID'}</div>
                    <div className="text-slate-500"># Processo terminado</div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {/* Status */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2 text-sm">
                <div className={`w-3 h-3 rounded-full ${
                  alert.status === 'resolved' ? 'bg-green-500' :
                  alert.status === 'analyzing' ? 'bg-blue-500 animate-pulse' :
                  'bg-orange-500'
                }`} />
                <span className="font-medium">Status:</span>
                <span className="text-slate-600">
                  {alert.status === 'pending' && 'Pendente'}
                  {alert.status === 'analyzing' && 'Analisando'}
                  {alert.status === 'awaiting_decision' && 'Aguardando Decisão'}
                  {alert.status === 'resolved' && 'Resolvido'}
                  {alert.status === 'ignored' && 'Ignorado'}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
