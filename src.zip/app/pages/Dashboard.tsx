import { AlertTriangle, Bug, CheckCircle, Clock, Shield, XCircle, Activity } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { mockAlerts, mockVulnerabilities, mockAuditLogs } from "../data/mockData";
import { Link } from "react-router";
import { Badge } from "../components/ui/badge";

export function Dashboard() {
  const criticalAlerts = mockAlerts.filter(a => a.level >= 12).length;
  const pendingAlerts = mockAlerts.filter(a => a.status === "pending" || a.status === "analyzing").length;
  
  const criticalVulns = mockVulnerabilities.filter(v => v.severity === "critical").length;
  const highVulns = mockVulnerabilities.filter(v => v.severity === "high").length;
  
  const recentActions = mockAuditLogs.slice(0, 5);

  const stats = [
    {
      title: "Alertas Críticos",
      value: criticalAlerts,
      icon: AlertTriangle,
      color: "text-red-600",
      bgColor: "bg-red-50",
      link: "/alerts",
    },
    {
      title: "Alertas Pendentes",
      value: pendingAlerts,
      icon: Clock,
      color: "text-orange-600",
      bgColor: "bg-orange-50",
      link: "/alerts",
    },
    {
      title: "Vulnerabilidades Críticas",
      value: criticalVulns,
      icon: Bug,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
      link: "/vulnerabilities",
    },
    {
      title: "Vulnerabilidades Altas",
      value: highVulns,
      icon: Shield,
      color: "text-yellow-600",
      bgColor: "bg-yellow-50",
      link: "/vulnerabilities",
    },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">Dashboard - Visão Geral</h2>
        <p className="text-slate-600 mt-1">Monitoramento em tempo real de alertas e vulnerabilidades do Wazuh</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Link key={stat.title} to={stat.link}>
              <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-600">{stat.title}</p>
                      <p className="text-3xl font-bold mt-2">{stat.value}</p>
                    </div>
                    <div className={`${stat.bgColor} p-3 rounded-lg`}>
                      <Icon className={`w-6 h-6 ${stat.color}`} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Alerts */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              Alertas Recentes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockAlerts.slice(0, 4).map((alert) => (
                <Link 
                  key={alert.id} 
                  to={`/alerts/${alert.id}`}
                  className="block p-3 rounded-lg border border-slate-200 hover:border-blue-300 hover:bg-blue-50/50 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge 
                          variant={alert.level >= 12 ? "destructive" : alert.level >= 8 ? "default" : "secondary"}
                        >
                          Level {alert.level}
                        </Badge>
                        <span className="text-xs text-slate-500">
                          {new Date(alert.timestamp).toLocaleString('pt-BR')}
                        </span>
                      </div>
                      <p className="text-sm font-medium text-slate-900">{alert.rule.description}</p>
                      <p className="text-xs text-slate-600 mt-1">
                        {alert.agentName} ({alert.agentIp})
                      </p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
            <Link 
              to="/alerts" 
              className="block text-center mt-4 text-sm text-blue-600 hover:text-blue-700 font-medium"
            >
              Ver todos os alertas →
            </Link>
          </CardContent>
        </Card>

        {/* Recent Vulnerabilities */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bug className="w-5 h-5 text-purple-600" />
              Vulnerabilidades Recentes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockVulnerabilities.slice(0, 4).map((vuln) => (
                <Link 
                  key={vuln.id} 
                  to={`/vulnerabilities/${vuln.id}`}
                  className="block p-3 rounded-lg border border-slate-200 hover:border-purple-300 hover:bg-purple-50/50 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge 
                          variant={vuln.severity === "critical" ? "destructive" : "default"}
                        >
                          {vuln.severity.toUpperCase()}
                        </Badge>
                        <span className="text-xs font-mono text-slate-600">{vuln.cve}</span>
                      </div>
                      <p className="text-sm font-medium text-slate-900">{vuln.description}</p>
                      <p className="text-xs text-slate-600 mt-1">
                        {vuln.agentName} - {vuln.package} ({vuln.version})
                      </p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
            <Link 
              to="/vulnerabilities" 
              className="block text-center mt-4 text-sm text-purple-600 hover:text-purple-700 font-medium"
            >
              Ver todas as vulnerabilidades →
            </Link>
          </CardContent>
        </Card>
      </div>

      {/* Recent Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-blue-600" />
            Ações Recentes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recentActions.map((log) => (
              <div key={log.id} className="flex items-center gap-3 p-3 rounded-lg bg-slate-50">
                {log.success ? (
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                ) : (
                  <XCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
                )}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-900">{log.details}</p>
                  <p className="text-xs text-slate-600 mt-0.5">
                    {log.analyst} • {new Date(log.timestamp).toLocaleString('pt-BR')}
                  </p>
                </div>
                <Badge variant="outline" className="flex-shrink-0">
                  {log.action}
                </Badge>
              </div>
            ))}
          </div>
          <Link 
            to="/audit-logs" 
            className="block text-center mt-4 text-sm text-blue-600 hover:text-blue-700 font-medium"
          >
            Ver todos os logs →
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}