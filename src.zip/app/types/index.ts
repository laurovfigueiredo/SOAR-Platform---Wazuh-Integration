export type AlertLevel = 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 15;

export type AlertStatus = "pending" | "analyzing" | "awaiting_decision" | "resolved" | "ignored" | "quarantined";

export type VulnerabilityStatus = "detected" | "analyzing" | "awaiting_patch" | "patching" | "resolved" | "quarantined";

export type ActionType = "containment" | "remediation" | "ignore";

export interface ThreatIntel {
  source: string;
  reputation: "malicious" | "suspicious" | "clean" | "unknown";
  score: number;
  details: string;
  lastAnalysis?: string;
}

export interface Alert {
  id: string;
  timestamp: string;
  level: AlertLevel;
  agentId: string;
  agentName: string;
  agentIp: string;
  sourceIp?: string;
  rule: {
    id: number;
    description: string;
    mitre: string[];
  };
  filePath?: string;
  processName?: string;
  status: AlertStatus;
  threatIntel?: ThreatIntel[];
  enrichmentComplete: boolean;
}

export interface Vulnerability {
  id: string;
  cve: string;
  timestamp: string;
  agentId: string;
  agentName: string;
  agentIp: string;
  package: string;
  version: string;
  cvssScore: number;
  severity: "critical" | "high" | "medium" | "low";
  description: string;
  status: VulnerabilityStatus;
  exploitable?: boolean;
  threatIntel?: ThreatIntel[];
  patchAvailable: boolean;
  patchVersion?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  analyst: string;
  action: ActionType | "scan" | "enrich";
  target: string;
  targetType: "alert" | "vulnerability";
  details: string;
  success: boolean;
  oldStatus?: string;
  newStatus?: string;
}

export interface QuarantineItem {
  id: string;
  timestamp: string;
  type: "alert" | "vulnerability";
  originalId: string;
  agentName: string;
  agentIp: string;
  description: string;
  reason: string;
  analyst: string;
}
